"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"
import { useState } from "react"

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  return (
    <header className="bg-[#1e3a8a] text-white">
      {/* Top bar */}
      <div className="bg-[#1e40af] px-4 py-1 text-xs text-center overflow-hidden relative">
        <div className="animate-pulse">
          <div className="animate-bounce inline-block ticker">🎓 Admissions Open - Enroll Now ! 🎓</div>
        </div>
        <style jsx>{`
          @keyframes ticker {
            0% { transform: translateX(100%); }
            100% { transform: translateX(-100%); }
          }
          .ticker {
            animation: ticker 15s linear infinite;
          }
        `}</style>
      </div>

      {/* Main header */}
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 md:gap-4">
            <div className="w-20 h-20 md:w-32 md:h-32 relative bg-transparent rounded-lg p-1 flex items-center justify-center">
              <Image
                src="/logo.jpg"
                alt="Airmanship Aviation Academy Logo"
                width={120}
                height={120}
                className="object-contain w-full h-full"
              />
            </div>
            <div>
              <h1 className="text-lg md:text-xl font-bold">Airmanship Aviation</h1>
              <p className="text-xs md:text-sm opacity-90">Flying Training Academy</p>
            </div>
          </Link>

          {/* Navigation - Desktop */}
          <nav className="hidden lg:flex items-center gap-8">
            <Link href="/" className="hover:text-blue-200 transition-colors">
              Home
            </Link>
            <Link href="/our-fleet" className="hover:text-blue-200 transition-colors">
              Our Fleet
            </Link>
            <Link href="/about" className="hover:text-blue-200 transition-colors leading-5 tracking-normal gap-0">
              About Us
            </Link>
            <Link href="/courses" className="hover:text-blue-200 transition-colors">
              Our Courses
            </Link>
            <Link href="/careers" className="hover:text-blue-200 transition-colors">
              Careers
            </Link>
            <Link href="/contact" className="hover:text-blue-200 transition-colors">
              Contact Us
            </Link>
          </nav>

          {/* Action buttons */}
          <div className="flex items-center gap-2 md:gap-3">
            <Button
              variant="outline"
              className="bg-transparent border-white text-white hover:bg-white hover:text-[#1e3a8a] hidden sm:inline-flex text-xs md:text-sm px-3 md:px-4"
            >
              ENQUIRE NOW
            </Button>
            <Button className="bg-white text-[#1e3a8a] hover:bg-gray-100 text-xs md:text-sm px-3 md:px-4">
              BROCHURE
            </Button>

            {/* Mobile menu button */}
            <button className="lg:hidden p-2" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <nav className="lg:hidden mt-4 pb-4 border-t border-blue-600 pt-4">
            <div className="flex flex-col gap-3">
              <Link href="/" className="hover:text-blue-200 transition-colors py-2">
                Home
              </Link>
              <Link href="/our-fleet" className="hover:text-blue-200 transition-colors py-2">
                Our Fleet
              </Link>
              <Link href="/about" className="hover:text-blue-200 transition-colors py-2">
                About Us
              </Link>
              <Link href="/courses" className="hover:text-blue-200 transition-colors py-2">
                Our Courses
              </Link>
              <Link href="/careers" className="hover:text-blue-200 transition-colors py-2">
                Careers
              </Link>
              <Link href="/contact" className="hover:text-blue-200 transition-colors py-2">
                Contact Us
              </Link>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}
