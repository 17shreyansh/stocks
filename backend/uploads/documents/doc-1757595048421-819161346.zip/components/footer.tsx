import Link from "next/link"
import { Instagram, Linkedin, Facebook, Youtube } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-[#1e3a8a] text-white">
      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {/* External Links */}
          <div className="space-y-3">
            <h3 className="text-base md:text-lg font-semibold mb-3 md:mb-4">EXTERNAL LINKS</h3>
            <ul className="space-y-2">
              <li>
                <a
                  href="https://www.dgca.gov.in"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-white transition-colors text-sm md:text-base"
                >
                  DGCA
                </a>
              </li>
              <li>
                <a
                  href="https://pariksha.dgca.gov.in/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-white transition-colors text-sm md:text-base"
                >
                  DGCA Exam Portal
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  Pilot Notice Board
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  Class 1 Medical
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  Class 2 Medical
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  Privacy Policy
                </a>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h3 className="text-base md:text-lg font-semibold mb-3 md:mb-4">QUICK LINKS</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  About Us
                </Link>
              </li>
              <li>
                <Link
                  href="/our-fleet"
                  className="text-gray-300 hover:text-white transition-colors text-sm md:text-base"
                >
                  Our Fleet
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  Commercial Pilot Program
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  Private Pilot Program
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  Conversion Flying
                </a>
              </li>
              <li>
                <Link href="/careers" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  Contact Us
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  FAQS
                </a>
              </li>
            </ul>
          </div>

          {/* Connect With Us */}
          <div className="space-y-3">
            <h3 className="text-base md:text-lg font-semibold mb-3 md:mb-4">CONNECT WITH US</h3>
            <ul className="space-y-3">
              <li className="flex items-center">
                <Instagram className="w-4 h-4 md:w-5 md:h-5 mr-3 text-pink-400 flex-shrink-0" />
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  Instagram
                </a>
              </li>
              <li className="flex items-center">
                <Linkedin className="w-4 h-4 md:w-5 md:h-5 mr-3 text-blue-400 flex-shrink-0" />
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  Linkedin
                </a>
              </li>
              <li className="flex items-center">
                <Facebook className="w-4 h-4 md:w-5 md:h-5 mr-3 text-blue-500 flex-shrink-0" />
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  Facebook
                </a>
              </li>
              <li className="flex items-center">
                <Youtube className="w-4 h-4 md:w-5 md:h-5 mr-3 text-red-500 flex-shrink-0" />
                <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                  YouTube
                </a>
              </li>
            </ul>
          </div>

          {/* Reach Out To Us */}
          <div className="space-y-3 sm:col-span-2 lg:col-span-1">
            <h3 className="text-base md:text-lg font-semibold mb-3 md:mb-4">REACH OUT TO US</h3>
            <div className="space-y-4 text-xs md:text-sm">
              <div>
                <div className="flex items-start mb-2">
                  <span className="mr-2 mt-1 text-sm">📍</span>
                  <div className="flex-1">
                    <p className="font-medium text-sm">Admission Office/Ground Classes:</p>
                    <p className="text-gray-300 leading-relaxed">
                      1st Floor, New Palam Vihar, Near HDFC Bank, Bajghera Gurugram Haryana - 122017
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-start mb-2">
                  <span className="mr-2 mt-1 text-sm">✈️</span>
                  <div className="flex-1">
                    <p className="font-medium text-sm">Airbase:</p>
                    <p className="text-gray-300">Satna Airport, Madhya Pradesh - 485001</p>
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-start mb-2">
                  <span className="mr-2 mt-1 text-sm">📧</span>
                  <div className="flex-1">
                    <p className="font-medium text-sm">Email:</p>
                    <a href="mailto:admin@airmanshipaviation.com" className="text-gray-300 hover:text-white break-all">
                      admin@airmanshipaviation.com
                    </a>
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-start">
                  <span className="mr-2 mt-1 text-sm">📞</span>
                  <div className="flex-1">
                    <p className="font-medium text-sm">Phone No.:</p>
                    <div className="text-gray-300 space-y-1">
                      <a href="tel:+917838108320" className="block hover:text-white">
                        +91 7838108320
                      </a>
                      <a href="tel:+919899007831" className="block hover:text-white">
                        +91 9899007831
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-blue-700 py-3 md:py-4">
        <div className="container mx-auto px-4 text-center">
          <p className="text-gray-300 text-xs md:text-sm">AIRMANSHIP AVIATION © 2025 ALL RIGHTS RESERVED</p>
        </div>
      </div>

      {/* WhatsApp Float Button */}
      <div className="fixed bottom-4 right-4 md:bottom-6 md:right-6 z-50">
        <a
          href="https://wa.me/919899007831"
          target="_blank"
          rel="noopener noreferrer"
          className="bg-green-500 hover:bg-green-600 text-white p-3 md:p-3 rounded-full shadow-lg transition-colors block w-12 h-12 md:w-auto md:h-auto flex items-center justify-center"
        >
          <svg className="w-5 h-5 md:w-6 md:h-6" fill="currentColor" viewBox="0 0 24 24">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488" />
          </svg>
        </a>
      </div>
    </footer>
  )
}
