import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export default function HeroSection() {
  return (
    <section className="relative min-h-screen bg-gradient-to-b from-blue-50 to-blue-100">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/aviation-hangar-with-aircraft-and-pilot-trainees-i.jpg"
          alt="Aviation training facility with pilots"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-black/30"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-8 sm:py-12 md:py-20">
        <div className="grid lg:grid-cols-2 gap-6 sm:gap-8 md:gap-12 items-center min-h-[calc(100vh-8rem)] sm:min-h-[80vh]">
          {/* Left Content */}
          <div className="space-y-4 sm:space-y-6 md:space-y-8 order-2 lg:order-1">
            <Card className="bg-white/95 backdrop-blur-sm p-4 sm:p-6 md:p-8 rounded-2xl shadow-xl w-full max-w-md mx-auto lg:mx-0">
              <div className="space-y-3 sm:space-y-4 md:space-y-6">
                <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-[#1e3a8a] leading-tight text-center lg:text-left">
                  Welcome to Airmanship Aviation Flight Training Academy
                </h2>
                <p className="text-gray-700 leading-relaxed text-sm sm:text-base text-center lg:text-left">
                  At our renowned pilot training institute, we blend passion of flying with decades of expertise to help you take flight and unlock your aviation journey with us.
                  We Believe in Transforming your aviation dreams into reality because your destination is in our way.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 md:gap-4">
                  <Button className="bg-[#1e3a8a] hover:bg-[#1e40af] text-white px-4 sm:px-6 md:px-8 py-3 text-sm sm:text-base w-full sm:w-auto">
                    Start Your Journey Today
                  </Button>
                  <Button
                    variant="outline"
                    className="border-[#1e3a8a] text-[#1e3a8a] hover:bg-[#1e3a8a] hover:text-white px-4 sm:px-6 md:px-8 py-3 text-sm sm:text-base bg-white/90 w-full sm:w-auto"
                  >
                    Learn More
                  </Button>
                </div>
              </div>
            </Card>

            {/* Features */}
            <div className="grid grid-cols-3 gap-2 sm:gap-3 md:gap-4 max-w-sm sm:max-w-md mx-auto lg:mx-0">
              <Card className="bg-white/90 backdrop-blur-sm p-2 sm:p-3 md:p-4 text-center">
                <div className="text-lg sm:text-xl md:text-2xl font-bold text-[#1e3a8a]">5+</div>
                <div className="text-xs sm:text-sm text-gray-600 leading-tight">Pilots Trained</div>
              </Card>
              <Card className="bg-white/90 backdrop-blur-sm p-2 sm:p-3 md:p-4 text-center">
                <div className="text-lg sm:text-xl md:text-2xl font-bold text-[#1e3a8a]">6+</div>
                <div className="text-xs sm:text-sm text-gray-600 leading-tight">Aircraft Fleet</div>
              </Card>
              <Card className="bg-white/90 backdrop-blur-sm p-2 sm:p-3 md:p-4 text-center">
                <div className="text-lg sm:text-xl md:text-2xl font-bold text-[#1e3a8a]">100%</div>
                <div className="text-xs sm:text-sm text-gray-600 leading-tight">DGCA Curriculum</div>
              </Card>
            </div>
          </div>

          {/* Right Content - Mobile visible image */}
          <div className="order-1 lg:order-2">
            <div className="relative max-w-xs sm:max-w-sm md:max-w-md mx-auto">
              <img
                src="/group-of-pilot-trainees-in-white-uniforms-with-avi.jpg"
                alt="Pilot trainees in uniform"
                className="w-full h-auto rounded-xl sm:rounded-2xl shadow-2xl object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-xl sm:rounded-2xl lg:hidden"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg className="w-full h-20 text-white" fill="currentColor" viewBox="0 0 1200 120" preserveAspectRatio="none">
          <path
            d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z"
            opacity=".25"
          ></path>
          <path
            d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z"
            opacity=".5"
          ></path>
          <path d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z"></path>
        </svg>
      </div>
    </section>
  )
}
