import Header from "@/components/header"
import Footer from "@/components/footer"

export default function CareersPage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section
        className="py-20 relative"
        style={{
          background: "linear-gradient(135deg, #1e3a8a 0%, #1d4ed8 100%)",
          minHeight: "400px",
        }}
      >
        <div className="container mx-auto px-4 py-20 relative z-10">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-white">Careers</h1>
          <p className="text-xl text-white opacity-90">Join Our Team of Aviation Professionals</p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-blue-900 mb-4">Build Your Aviation Career</h2>
              <p className="text-lg text-gray-700">
                Discover exciting opportunities to grow your career in the aviation industry with Airmanship
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
              <div className="bg-blue-50 rounded-lg p-6">
                <h3 className="text-xl font-bold text-blue-900 mb-4">Flight Instructors</h3>
                <p className="text-gray-700 mb-4">
                  Join our team of experienced flight instructors and help shape the next generation of pilots.
                </p>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3 flex-shrink-0"></span>
                    Commercial Pilot License required
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3 flex-shrink-0"></span>
                    Instructor rating preferred
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3 flex-shrink-0"></span>
                    Minimum 500 hours flight time
                  </li>
                </ul>
              </div>

              <div className="bg-blue-50 rounded-lg p-6">
                <h3 className="text-xl font-bold text-blue-900 mb-4">Ground Instructors</h3>
                <p className="text-gray-700 mb-4">
                  Teach theoretical knowledge and help students prepare for their aviation examinations.
                </p>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3 flex-shrink-0"></span>
                    Aviation degree preferred
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3 flex-shrink-0"></span>
                    Teaching experience
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3 flex-shrink-0"></span>
                    DGCA ground instructor license
                  </li>
                </ul>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-6 md:p-8 mb-12">
              <h3 className="text-2xl font-bold text-blue-900 mb-6">Why Work With Us?</h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3 flex-shrink-0"></span>
                    Competitive salary packages
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3 flex-shrink-0"></span>
                    Professional development opportunities
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3 flex-shrink-0"></span>
                    Modern training facilities
                  </li>
                </ul>
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3 flex-shrink-0"></span>
                    Supportive work environment
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3 flex-shrink-0"></span>
                    Career advancement paths
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3 flex-shrink-0"></span>
                    Industry networking opportunities
                  </li>
                </ul>
              </div>
            </div>

            <div className="text-center">
              <h3 className="text-2xl font-bold text-blue-900 mb-4">Ready to Join Our Team?</h3>
              <p className="text-lg text-gray-700 mb-6">
                Send your resume and cover letter to start your career with Airmanship Aviation
              </p>
              <a
                href="mailto:admin@airmanshipaviation.com?subject=Job Application - Airmanship Aviation Academy&body=Dear Hiring Manager,%0D%0A%0D%0AI am interested in applying for a position at Airmanship Aviation Academy. Please find my resume and cover letter attached.%0D%0A%0D%0APosition of Interest: [Please specify]%0D%0AYears of Experience: [Please specify]%0D%0AFlight Hours (if applicable): [Please specify]%0D%0A%0D%0AThank you for your consideration.%0D%0A%0D%0ABest regards,%0D%0A[Your Name]"
                className="bg-blue-900 text-white px-8 py-3 rounded-full hover:bg-blue-800 transition-colors inline-block font-semibold"
              >
                Apply Now
              </a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
