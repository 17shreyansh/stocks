import Header from "@/components/header"
import Footer from "@/components/footer"

export default function CoursesPage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-blue-700 text-white py-20">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Courses</h1>
          <p className="text-xl text-blue-100">Professional Pilot Training Programs</p>
        </div>
      </section>

      {/* Courses Content */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Commercial Pilot Program */}
              <div className="bg-white rounded-lg shadow-lg p-6 border border-gray-200">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl">✈️</span>
                  </div>
                  <h3 className="text-xl font-bold text-blue-900">Commercial Pilot Program</h3>
                </div>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    200 hours flight time
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    DGCA approved curriculum
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    Instrument rating included
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    Multi-engine training
                  </li>
                </ul>
              </div>

              {/* Private Pilot Program */}
              <div className="bg-white rounded-lg shadow-lg p-6 border border-gray-200">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl">🛩️</span>
                  </div>
                  <h3 className="text-xl font-bold text-blue-900">Private Pilot Program</h3>
                </div>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    40 hours minimum flight time
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    Ground school included
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    Solo flight training
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    Cross-country flights
                  </li>
                </ul>
              </div>

              {/* Conversion Flying */}
              <div className="bg-white rounded-lg shadow-lg p-6 border border-gray-200">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl">🔄</span>
                  </div>
                  <h3 className="text-xl font-bold text-blue-900">Conversion Flying</h3>
                </div>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    License conversion
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    Type rating courses
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    Recency training
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    Skill enhancement
                  </li>
                </ul>
              </div>
            </div>

            {/* Additional Information */}
            <div className="mt-16 bg-blue-50 rounded-lg p-8">
              <h3 className="text-2xl font-bold text-blue-900 mb-6 text-center">Why Choose Airmanship Aviation?</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-lg font-semibold text-blue-800 mb-3">Expert Instructors</h4>
                  <p className="text-gray-700">
                    Learn from experienced pilots with thousands of flight hours and proven teaching methods.
                  </p>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-blue-800 mb-3">Modern Facilities</h4>
                  <p className="text-gray-700">
                    Train with state-of-the-art equipment and well-maintained aircraft in a professional environment.
                  </p>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-blue-800 mb-3">DGCA Approved</h4>
                  <p className="text-gray-700">
                    All our programs are fully approved by DGCA, ensuring the highest standards of aviation training.
                  </p>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-blue-800 mb-3">Career Support</h4>
                  <p className="text-gray-700">
                    Get guidance and support for your aviation career with our industry connections and placement
                    assistance.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
