import Header from "@/components/header"
import Footer from "@/components/footer"
import Image from "next/image"

export default function AboutPage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section
        className="text-white py-20"
        style={{
          background: "linear-gradient(to right, #1e3a8a, #1e40af)",
          backgroundColor: "#1e3a8a",
        }}
      >
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4" style={{ color: "#ffffff" }}>
            About Us
          </h1>
          <p className="text-xl opacity-90" style={{ color: "#ffffff" }}>
            DGCA APPROVED PPL, CPL & GROUND SCHOOL
          </p>
        </div>
      </section>

      {/* About Content */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              Airmanship Aviation Flying Training Academy (AAA) stands as one of India's premier pilot training
              institutions, where dreams take flight. We are a proud DGCA-approved Private Pilot License (PPL) program,
              Commercial Pilot License (CPL) program, and Ground School, committed to shaping the future of aviation
              through world-class training and uncompromising dedication to excellence.
            </p>

            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              At Airmanship, we understand that aviation is not just a career but a lifelong passion and dream for many.
              Our comprehensive training programs are meticulously designed to transform aspiring aviators into skilled,
              confident, and safety-conscious pilots through world-class training and state-of-the-art facilities.
            </p>

            <p className="text-lg text-gray-700 mb-12 leading-relaxed">
              Our commitment to quality education is evident in every aspect of our institute. From our experienced
              instructors to our modern fleet of aircraft, we ensure that our students receive the highest standards of
              education and practical training. We take pride in our proven track record of producing competent pilots
              who have gone on to successful careers in commercial aviation, making their mark in the skies and
              contributing to the growth of the aviation industry.
            </p>

            {/* Aircraft Image */}
            <div className="mb-12">
              <Image
                src="/aircraft-hangar-interior.jpg"
                alt="VFTI Aircraft Hangar with Training Aircraft"
                width={800}
                height={600}
                className="w-full rounded-lg shadow-lg"
              />
            </div>

            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              Our commitment to quality education is evident in every aspect of our institute. From our methodically
              designed curriculum to our comprehensive training modules, we ensure that our students are equipped with
              the knowledge and skills necessary to excel in their aviation careers. At Airmanship Aviation, we believe
              that quality training and hands-on experience are the foundations of successful aviation careers.
            </p>

            <p className="text-lg text-gray-700 mb-12 leading-relaxed">
              We don't just train pilots we nurture aviation professionals who are equipped with the skills and
              knowledge to soar to new heights. Together, we will navigate the skies and chart a course for success.
            </p>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-blue-900 mb-4">Our Gallery</h2>
            <button className="bg-blue-900 text-white px-6 py-2 rounded-full hover:bg-blue-800 transition-colors">
              VIEW MORE →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <Image
                src="/training-classroom.jpg"
                alt="AAA Training Classroom"
                width={400}
                height={300}
                className="w-full h-48 object-cover"
              />
            </div>
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <Image
                src="/aircraft-maintenance.jpg"
                alt="Aircraft Maintenance Training"
                width={400}
                height={300}
                className="w-full h-48 object-cover"
              />
            </div>
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <Image
                src="/hangar-overview.jpg"
                alt="AAA Hangar Overview"
                width={400}
                height={300}
                className="w-full h-48 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
